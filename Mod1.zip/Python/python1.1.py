Python 3.3.2 (v3.3.2:d047928ae3f6, May 16 2013, 00:03:43) [MSC v.1600 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> s1="Hello world"
>>> s1.spline
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    s1.spline
AttributeError: 'str' object has no attribute 'spline'
>>> s1.spline()
Traceback (most recent call last):
  File "<pyshell#2>", line 1, in <module>
    s1.spline()
AttributeError: 'str' object has no attribute 'spline'
>>> s1.split()
['Hello', 'world']
>>> s1.split(' ')
['Hello', 'world']
>>> s1.splittlines()
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    s1.splittlines()
AttributeError: 'str' object has no attribute 'splittlines'
>>> s1.splitlines()
['Hello world']
>>> s1=s1+'\n'+s1
>>> s1
'Hello world\nHello world'
>>> s1
'Hello world\nHello world'
>>> s1="h w"
>>> s1="this is the first line"
>>> print('the sting is {0}'.format(s1))
the sting is this is the first line
>>> "p" in "apple"
True
>>> x=None
>>> x
>>> id(x)
505672132
>>> x=1
>>> id(x)
505910864
>>> s2
Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    s2
NameError: name 's2' is not defined
>>> s1
'this is the first line'
>>> s2=s1.split(' ')
>>> s2
['this', 'is', 'the', 'first', 'line']
>>> type(s2)
<class 'list'>
>>> s2[-1]
'line'
>>> s2[-2]
'first'
>>> s2[0]
'this'
>>> s2[1:4]
['is', 'the', 'first']
>>> s2[:3]
['this', 'is', 'the']
>>> s2[:]
['this', 'is', 'the', 'first', 'line']
>>> nested=[1,10.0,s1]
>>> nested
[1, 10.0, 'this is the first line']
>>> nested=[1,10.0,s1,s2]
>>> nested
[1, 10.0, 'this is the first line', ['this', 'is', 'the', 'first', 'line']]
>>> nested[3][2]
'the'
>>> s2[2-4]
'first'
>>> s2[2-6]
'is'
>>> s2[5:2]
[]
>>> s2[4:3]
[]
>>> s2
['this', 'is', 'the', 'first', 'line']
>>> s2[3]
'first'
>>> :
	
SyntaxError: invalid syntax
>>> s2[3:]
['first', 'line']
>>> s2.append('hey')
>>> s2
['this', 'is', 'the', 'first', 'line', 'hey']
>>> nested
[1, 10.0, 'this is the first line', ['this', 'is', 'the', 'first', 'line', 'hey']]
'
>>> s1+='hey'
>>> s1
'this is the first linehey'
>>> neste
Traceback (most recent call last):
  File "<pyshell#48>", line 1, in <module>
    neste
NameError: name 'neste' is not defined
>>> neted
Traceback (most recent call last):
  File "<pyshell#49>", line 1, in <module>
    neted
NameError: name 'neted' is not defined
>>> nested
[1, 10.0, 'this is the first line', ['this', 'is', 'the', 'first', 'line', 'hey']]
>>> len(s1)
25
>>> len(s2)
6
>>> 
s2.pop()
'hey'
>>> s2
['this', 'is', 'the', 'first', 'line']
>>> s2.push('hey')
Traceback (most recent call last):
  File "<pyshell#55>", line 1, in <module>
    s2.push('hey')
AttributeError: 'list' object has no attribute 'push'
>>> help (list)
Help on class list in module builtins:

class list(object)
 |  list() -> new empty list
 |  list(iterable) -> new list initialized from iterable's items
 |  
 |  Methods defined here:
 |  
 |  __add__(...)
 |      x.__add__(y) <==> x+y
 |  
 |  __contains__(...)
 |      x.__contains__(y) <==> y in x
 |  
 |  __delitem__(...)
 |      x.__delitem__(y) <==> del x[y]
 |  
 |  __eq__(...)
 |      x.__eq__(y) <==> x==y
 |  
 |  __ge__(...)
 |      x.__ge__(y) <==> x>=y
 |  
 |  __getattribute__(...)
 |      x.__getattribute__('name') <==> x.name
 |  
 |  __getitem__(...)
 |      x.__getitem__(y) <==> x[y]
 |  
 |  __gt__(...)
 |      x.__gt__(y) <==> x>y
 |  
 |  __iadd__(...)
 |      x.__iadd__(y) <==> x+=y
 |  
 |  __imul__(...)
 |      x.__imul__(y) <==> x*=y
 |  
 |  __init__(...)
 |      x.__init__(...) initializes x; see help(type(x)) for signature
 |  
 |  __iter__(...)
 |      x.__iter__() <==> iter(x)
 |  
 |  __le__(...)
 |      x.__le__(y) <==> x<=y
 |  
 |  __len__(...)
 |      x.__len__() <==> len(x)
 |  
 |  __lt__(...)
 |      x.__lt__(y) <==> x<y
 |  
 |  __mul__(...)
 |      x.__mul__(n) <==> x*n
 |  
 |  __ne__(...)
 |      x.__ne__(y) <==> x!=y
 |  
 |  __repr__(...)
 |      x.__repr__() <==> repr(x)
 |  
 |  __reversed__(...)
 |      L.__reversed__() -- return a reverse iterator over the list
 |  
 |  __rmul__(...)
 |      x.__rmul__(n) <==> n*x
 |  
 |  __setitem__(...)
 |      x.__setitem__(i, y) <==> x[i]=y
 |  
 |  __sizeof__(...)
 |      L.__sizeof__() -- size of L in memory, in bytes
 |  
 |  append(...)
 |      L.append(object) -> None -- append object to end
 |  
 |  clear(...)
 |      L.clear() -> None -- remove all items from L
 |  
 |  copy(...)
 |      L.copy() -> list -- a shallow copy of L
 |  
 |  count(...)
 |      L.count(value) -> integer -- return number of occurrences of value
 |  
 |  extend(...)
 |      L.extend(iterable) -> None -- extend list by appending elements from the iterable
 |  
 |  index(...)
 |      L.index(value, [start, [stop]]) -> integer -- return first index of value.
 |      Raises ValueError if the value is not present.
 |  
 |  insert(...)
 |      L.insert(index, object) -- insert object before index
 |  
 |  pop(...)
 |      L.pop([index]) -> item -- remove and return item at index (default last).
 |      Raises IndexError if list is empty or index is out of range.
 |  
 |  remove(...)
 |      L.remove(value) -> None -- remove first occurrence of value.
 |      Raises ValueError if the value is not present.
 |  
 |  reverse(...)
 |      L.reverse() -- reverse *IN PLACE*
 |  
 |  sort(...)
 |      L.sort(key=None, reverse=False) -> None -- stable sort *IN PLACE*
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __hash__ = None
 |  
 |  __new__ = <built-in method __new__ of type object>
 |      T.__new__(S, ...) -> a new object with type S, a subtype of T

>>> s2.reverse()
>>> s2
['line', 'first', 'the', 'is', 'this']
>>> s2.remove(0)
Traceback (most recent call last):
  File "<pyshell#59>", line 1, in <module>
    s2.remove(0)
ValueError: list.remove(x): x not in list
>>> s2.remove('line')
>>> s2
['first', 'the', 'is', 'this']
>>> s2.del(0)
SyntaxError: invalid syntax
>>> s=10
>>> del(s)
>>> s
Traceback (most recent call last):
  File "<pyshell#65>", line 1, in <module>
    s
NameError: name 's' is not defined
>>> s2.sort()\

	
>>> s2.sort
<built-in method sort of list object at 0x02E24BC0>
>>> s2.sort()
>>> s2
['first', 'is', 'the', 'this']
>>> nested
[1, 10.0, 'this is the first line', ['first', 'is', 'the', 'this']]
>>> s2[3][1]='second'
Traceback (most recent call last):
  File "<pyshell#72>", line 1, in <module>
    s2[3][1]='second'
TypeError: 'str' object does not support item assignment
>>> nested[3][1]='second'
>>> nested
[1, 10.0, 'this is the first line', ['first', 'second', 'the', 'this']]
>>> nested+s2
[1, 10.0, 'this is the first line', ['first', 'second', 'the', 'this'], 'first', 'second', 'the', 'this']
>>> nested
[1, 10.0, 'this is the first line', ['first', 'second', 'the', 'this']]
>>> nested+s1
Traceback (most recent call last):
  File "<pyshell#78>", line 1, in <module>
    nested+s1
TypeError: can only concatenate list (not "str") to list
>>> nested*2
[1, 10.0, 'this is the first line', ['first', 'second', 'the', 'this'], 1, 10.0, 'this is the first line', ['first', 'second', 'the', 'this']]
>>> s2*3
['first', 'second', 'the', 'this', 'first', 'second', 'the', 'this', 'first', 'second', 'the', 'this']
>>> s2.del()
SyntaxError: invalid syntax
>>> s2.del
SyntaxError: invalid syntax
>>> ss=[1,2,3,4]
>>> del(ss)
>>> ss
Traceback (most recent call last):
  File "<pyshell#85>", line 1, in <module>
    ss
NameError: name 'ss' is not defined
>>> ss=[1,2,3,4]
>>> clear(ss)
Traceback (most recent call last):
  File "<pyshell#87>", line 1, in <module>
    clear(ss)
NameError: name 'clear' is not defined
>>> ss.clear()
>>> ss
[]
>>> del(sss)
Traceback (most recent call last):
  File "<pyshell#90>", line 1, in <module>
    del(sss)
NameError: name 'sss' is not defined
>>> del(ss)
>>> 
ss=[1]
>>> ss
[1]
>>> type(ss)
<class 'list'>
>>> ss=(1)
>>> ss
1
>>> type(ss)
<class 'int'>
>>> ss=(1,2,3)
>>> type(ss)
<class 'tuple'>
>>> ss.append(4)
Traceback (most recent call last):
  File "<pyshell#100>", line 1, in <module>
    ss.append(4)
AttributeError: 'tuple' object has no attribute 'append'
>>> ss
(1, 2, 3)
>>> help(tuple)
Help on class tuple in module builtins:

class tuple(object)
 |  tuple() -> empty tuple
 |  tuple(iterable) -> tuple initialized from iterable's items
 |  
 |  If the argument is a tuple, the return value is the same object.
 |  
 |  Methods defined here:
 |  
 |  __add__(...)
 |      x.__add__(y) <==> x+y
 |  
 |  __contains__(...)
 |      x.__contains__(y) <==> y in x
 |  
 |  __eq__(...)
 |      x.__eq__(y) <==> x==y
 |  
 |  __ge__(...)
 |      x.__ge__(y) <==> x>=y
 |  
 |  __getattribute__(...)
 |      x.__getattribute__('name') <==> x.name
 |  
 |  __getitem__(...)
 |      x.__getitem__(y) <==> x[y]
 |  
 |  __getnewargs__(...)
 |  
 |  __gt__(...)
 |      x.__gt__(y) <==> x>y
 |  
 |  __hash__(...)
 |      x.__hash__() <==> hash(x)
 |  
 |  __iter__(...)
 |      x.__iter__() <==> iter(x)
 |  
 |  __le__(...)
 |      x.__le__(y) <==> x<=y
 |  
 |  __len__(...)
 |      x.__len__() <==> len(x)
 |  
 |  __lt__(...)
 |      x.__lt__(y) <==> x<y
 |  
 |  __mul__(...)
 |      x.__mul__(n) <==> x*n
 |  
 |  __ne__(...)
 |      x.__ne__(y) <==> x!=y
 |  
 |  __repr__(...)
 |      x.__repr__() <==> repr(x)
 |  
 |  __rmul__(...)
 |      x.__rmul__(n) <==> n*x
 |  
 |  __sizeof__(...)
 |      T.__sizeof__() -- size of T in memory, in bytes
 |  
 |  count(...)
 |      T.count(value) -> integer -- return number of occurrences of value
 |  
 |  index(...)
 |      T.index(value, [start, [stop]]) -> integer -- return first index of value.
 |      Raises ValueError if the value is not present.
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __new__ = <built-in method __new__ of type object>
 |      T.__new__(S, ...) -> a new object with type S, a subtype of T

>>> ss.add(4)
Traceback (most recent call last):
  File "<pyshell#103>", line 1, in <module>
    ss.add(4)
AttributeError: 'tuple' object has no attribute 'add'
>>> ss=ss.add(4)
Traceback (most recent call last):
  File "<pyshell#104>", line 1, in <module>
    ss=ss.add(4)
AttributeError: 'tuple' object has no attribute 'add'
>>> ss.append(4)
Traceback (most recent call last):
  File "<pyshell#105>", line 1, in <module>
    ss.append(4)
AttributeError: 'tuple' object has no attribute 'append'
>>> ss
(1, 2, 3)
>>> ss.clear()
Traceback (most recent call last):
  File "<pyshell#107>", line 1, in <module>
    ss.clear()
AttributeError: 'tuple' object has no attribute 'clear'
>>> ss
(1, 2, 3)
>>> del(ss)
>>> ss
Traceback (most recent call last):
  File "<pyshell#110>", line 1, in <module>
    ss
NameError: name 'ss' is not defined
>>> ss=(1,2,3)
>>> ss.add(4)
Traceback (most recent call last):
  File "<pyshell#112>", line 1, in <module>
    ss.add(4)
AttributeError: 'tuple' object has no attribute 'add'
>>> ss2=(4,5,6)
>>> ss+ss2
(1, 2, 3, 4, 5, 6)
>>> ss+
SyntaxError: invalid syntax
>>> ss+4
Traceback (most recent call last):
  File "<pyshell#116>", line 1, in <module>
    ss+4
TypeError: can only concatenate tuple (not "int") to tuple
>>> ss+(4)
Traceback (most recent call last):
  File "<pyshell#117>", line 1, in <module>
    ss+(4)
TypeError: can only concatenate tuple (not "int") to tuple
>>> ss+(4,5)
(1, 2, 3, 4, 5)
>>> ss+(4,)
(1, 2, 3, 4)
>>> ss
(1, 2, 3)
>>> a1,a2,a3=ss
>>> s1
'this is the first linehey'
>>> a1
1
>>> a2
2
>>> a3
3
>>> t1=(a1,a2,a3)
>>> t1
(1, 2, 3)
>>> t1=a1,a2,a3
>>> t1
(1, 2, 3)
>>> #dictionaries
>>> eng2sp={}
>>> eng2sp["one"]=1
>>> eng2sp["two"]=2
>>> eng2sp
{'two': 2, 'one': 1}
>>> d1={1:"one",2:"two"}
>>> d1
{1: 'one', 2: 'two'}
>>> d1={one:1,two=2}
SyntaxError: invalid syntax
>>> d1={one:1,two:2}
Traceback (most recent call last):
  File "<pyshell#138>", line 1, in <module>
    d1={one:1,two:2}
NameError: name 'one' is not defined
>>> d1={'one':1,'one':2}}
SyntaxError: invalid syntax
>>> d1={'one':1,'one':2}
>>> d1
{'one': 2}
>>> d1['two']=2
>>> d1
{'two': 2, 'one': 2}
>>> d1.keys()
dict_keys(['two', 'one'])
>>> lis(d1.keys())[1]
Traceback (most recent call last):
  File "<pyshell#145>", line 1, in <module>
    lis(d1.keys())[1]
NameError: name 'lis' is not defined
>>> list(d1.keys())[0]
'two'
>>> r1=range(3,10)
>>> r1
range(3, 10)
>>> iter(r1)
<range_iterator object at 0x02D94680>
>>> typ2(r1)
Traceback (most recent call last):
  File "<pyshell#150>", line 1, in <module>
    typ2(r1)
NameError: name 'typ2' is not defined
>>> type(r1)
<class 'range'>
>>> for x in r1:
	print(x)

	
3
4
5
6
7
8
9
>>> for k in d1.keys()
SyntaxError: invalid syntax
>>> for k in d1.keys():
	print(k)

	
two
one
>>> for k in d1.keys():
	print(d1[k])

	
2
2
>>> d1.get('one')
2
>>> d1.get('abc')
>>> d1.get('abc','key not found')
'key not found'
>>> set1={1,2,45,2,1,3,4,7,2}
>>> set1
{1, 2, 3, 4, 7, 45}
>>> 
