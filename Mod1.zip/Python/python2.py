Python 3.3.2 (v3.3.2:d047928ae3f6, May 16 2013, 00:03:43) [MSC v.1600 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> --path
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    --path
NameError: name 'path' is not defined
>>> --installationpath
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    --installationpath
NameError: name 'installationpath' is not defined
>>> help()

Welcome to Python 3.3!  This is the interactive help utility.

If this is your first time using Python, you should definitely check out
the tutorial on the Internet at http://docs.python.org/3.3/tutorial/.

Enter the name of any module, keyword, or topic to get help on writing
Python programs and using Python modules.  To quit this help utility and
return to the interpreter, just type "quit".

To get a list of available modules, keywords, or topics, type "modules",
"keywords", or "topics".  Each module also comes with a one-line summary
of what it does; to list the modules whose summaries contain a given word
such as "spam", type "modules spam".

help> install path
no Python documentation found for 'install path'

help> path
no Python documentation found for 'path'

help> python
no Python documentation found for 'python'

help> python3
no Python documentation found for 'python3'

help> python path
no Python documentation found for 'python path'

help> 

You are now leaving help and returning to the Python interpreter.
If you want to ask for help on a particular object directly from the
interpreter, you can type "help(object)".  Executing "help('string')"
has the same effect as typing a particular string at the help> prompt.
>>> which python
SyntaxError: invalid syntax
>>> import os
>>> import sys
>>> os.path.dirname(sys.executable)
'C:\\Python33'
>>> import os
>>> os.getcwd
<built-in function getcwd>
>>> os.getcwd()
'C:\\Python33'
>>> ================================ RESTART ================================
>>> 
No. #12
No. #23
Addition of 2 & 3 is 5
>>> ================================ RESTART ================================
>>> 
No. #1 3
No. #2 4
Addition of 3 & 4 is 7
>>> ================================ RESTART ================================
>>> 
No.(# to exit) 1
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 10, in <module>
    list.append(int(n))
MemoryError
2
3
4
5
#
>>> ================================ RESTART ================================
>>> 
No.(# to exit) 1
No.(# to exit) 2
No.(# to exit) 3
No.(# to exit) #
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 13, in <module>
    print('Addition of numbers is {0}'.format(add(list)))
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 4, in add
    sum+=int(a)
TypeError: int() argument must be a string or a number, not 'list'
>>> ================================ RESTART ================================
>>> 
No.(# to exit) 1
No.(# to exit) 2
No.(# to exit) 3
No.(# to exit) #
Addition of numbers is 7
>>> ================================ RESTART ================================
>>> 
No.(# to exit) 1
No.(# to exit) 2
No.(# to exit) 3
No.(# to exit) #
Addition of numbers is 7
>>> ================================ RESTART ================================
>>> 
No.(# to exit) 1
No.(# to exit) 2
No.(# to exit) #
Addition of numbers is 4
>>> ================================ RESTART ================================
>>> 
No.(# to exit) 1
No.(# to exit) 2
No.(# to exit) 3
No.(# to exit) #
Addition of numbers is 6
>>> ================================ RESTART ================================
>>> 
Enter No.(# to exit) 1
Enter No.(# to exit) 2
Enter No.(# to exit) 3
Enter No.(# to exit) #
Addition of numbers is 6
>>> ================================ RESTART ================================
>>> 
Enter No.(# to exit) 1
Enter No.(# to exit) 2
Enter No.(# to exit) 3
Enter No.(# to exit) #
<class 'list'>
Addition of numbers is 6
>>> ================================ RESTART ================================
>>> 
Enter No.(# to exit) 1
Enter No.(# to exit) 2
Enter No.(# to exit) 3
Enter No.(# to exit) #
<class 'tuple'>
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 15, in <module>
    print('Addition of numbers is {0}'.format(add(list)))
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 5, in add
    sum+=int(a)
TypeError: int() argument must be a string or a number, not 'list'
>>> ================================ RESTART ================================
>>> 
Enter No.(# to exit) 1
Enter No.(# to exit) 2
Enter No.(# to exit) 3
Enter No.(# to exit) #
<class 'list'>
Addition of numbers is 6
>>> ================================ RESTART ================================
>>> 
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 22, in <module>
    details(name='vanshaj',age=21,ide=2121)
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 20, in details
    print('Name: {0} Age: {1} ID: {3}'.format(name,age,ide))
IndexError: tuple index out of range
>>> ================================ RESTART ================================
>>> 
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 22, in <module>
    details(name='vanshaj',age=21,ide=2121)
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 20, in details
    print('Name: {0} Age: {1} ID: {3}'.format(name,age,ide))
IndexError: tuple index out of range
>>> ================================ RESTART ================================
>>> 
Name: vanshaj Age: 21 ID: 2121
Name: unknown Age: 32 ID: 12
Name: vanshaj Age: 3 ID: 3212
>>> ================================ RESTART ================================
>>> 
Name: vanshaj Age: 21 ID: 2121
Name: unknown Age: 32 ID: 12
Name: unknown Age: 32 ID: 12
Name: vanshaj Age: 3 ID: 3212
>>> ================================ RESTART ================================
>>> 
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 33, in <module>
    details(name='vanshaj',age=21,ide=2121)
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 31, in details
    print('Name: {0} Age: {1} ID: {2}'.format(name,age,ide))
NameError: global name 'name' is not defined
>>> ================================ RESTART ================================
>>> 
<class 'dict'>
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 34, in <module>
    details(name='vanshaj',age=21,ide=2121)
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 32, in details
    print('Name: {0} Age: {1} ID: {2}'.format(name,age,ide))
NameError: global name 'name' is not defined
>>> ================================ RESTART ================================
>>> 
<class 'dict'>
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 34, in <module>
    details(name='vanshaj',age=21,ide=2121)
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 32, in details
    print('Name: {0} Age: {1} ID: {2}'.format(parsms['name'],params['age'],params['ide']))
NameError: global name 'parsms' is not defined
>>> ================================ RESTART ================================
>>> 
<class 'dict'>
Name: vanshaj Age: 21 ID: 2121
<class 'dict'>
Traceback (most recent call last):
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 35, in <module>
    details(ide=12,age=32)
  File "D:/Users/ADM-IG-HWDLAB2E/Desktop/VanB/funct1.py", line 32, in details
    print('Name: {0} Age: {1} ID: {2}'.format(params['name'],params['age'],params['ide']))
KeyError: 'name'
>>> ================================ RESTART ================================
>>> 
<class 'dict'>
Name: vanshaj Age: 21 ID: 2121
<class 'dict'>
Name: vanshaj Age: 3 ID: 3212
>>> ================================ RESTART ================================
>>> 
Help on function details in module __main__:

details(**params)
    THIS IS MY DOC STREAM

None
<class 'dict'>
Name: vanshaj Age: 21 ID: 2121
<class 'dict'>
Name: vanshaj Age: 3 ID: 3212
>>> ================================ RESTART ================================
>>> 
Help on function details in module __main__:

details(**params)
    THIS IS MY DOC STREAM

None
<class 'dict'>
Name: vanshaj Age: 21 ID: 2121
<class 'dict'>
Name: vanshaj Age: 3 ID: 3212
>>> abc={}
>>> type(abc)
<class 'dict'>
>>> abc=set()
>>> type(abc)
<class 'set'>
>>> abc=dict()
>>> type(abc)
<class 'dict'>
>>> add=lambda x,y:x+y
>>> add(3,2)
5
>>> import math
>>> import math as m
>>> m.sqrt(4)
2.0
>>> from math import cos,sin,sqrt
>>> dir()
['__builtins__', '__doc__', '__file__', '__loader__', '__name__', '__package__', 'abc', 'add', 'cos', 'details', 'm', 'math', 'sin', 'sqrt']
>>> from math import *
>>> dir()
['__builtins__', '__doc__', '__file__', '__loader__', '__name__', '__package__', 'abc', 'acos', 'acosh', 'add', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees', 'details', 'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'hypot', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2', 'm', 'math', 'modf', 'pi', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'trunc']
>>> import calc
>>> dir()
['__builtins__', '__doc__', '__file__', '__loader__', '__name__', '__package__', 'abc', 'acos', 'acosh', 'add', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'calc', 'ceil', 'copysign', 'cos', 'cosh', 'degrees', 'details', 'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'hypot', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2', 'm', 'math', 'modf', 'pi', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'trunc']
>>> calc.sum(2,3)
Traceback (most recent call last):
  File "<pyshell#27>", line 1, in <module>
    calc.sum(2,3)
AttributeError: 'module' object has no attribute 'sum'
>>> import calc
>>> dir()
['__builtins__', '__doc__', '__file__', '__loader__', '__name__', '__package__', 'abc', 'acos', 'acosh', 'add', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'calc', 'ceil', 'copysign', 'cos', 'cosh', 'degrees', 'details', 'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'hypot', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2', 'm', 'math', 'modf', 'pi', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'trunc']
>>> calc.sum(1,2)
Traceback (most recent call last):
  File "<pyshell#30>", line 1, in <module>
    calc.sum(1,2)
AttributeError: 'module' object has no attribute 'sum'
>>> import sys
>>> sys.getcwd()
Traceback (most recent call last):
  File "<pyshell#32>", line 1, in <module>
    sys.getcwd()
AttributeError: 'module' object has no attribute 'getcwd'
>>> os.getcwd()
Traceback (most recent call last):
  File "<pyshell#33>", line 1, in <module>
    os.getcwd()
NameError: name 'os' is not defined
>>> import os
>>> os.getcwd()
'D:\\Users\\ADM-IG-HWDLAB2E\\Desktop\\VanB'
>>> import calc.py
Traceback (most recent call last):
  File "<frozen importlib._bootstrap>", line 1521, in _find_and_load_unlocked
AttributeError: 'module' object has no attribute '__path__'

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<pyshell#36>", line 1, in <module>
    import calc.py
ImportError: No module named 'calc.py'; calc is not a package
>>> import calc
>>> calc.sum(1,2)
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    calc.sum(1,2)
AttributeError: 'module' object has no attribute 'sum'
>>> calc.add(1,2)
3
>>> import Pkg1.calc
>>> dir()
['Pkg1', '__builtins__', '__doc__', '__file__', '__loader__', '__name__', '__package__', 'abc', 'acos', 'acosh', 'add', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'calc', 'ceil', 'copysign', 'cos', 'cosh', 'degrees', 'details', 'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'hypot', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2', 'm', 'math', 'modf', 'os', 'pi', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'sys', 'tan', 'tanh', 'trunc']
>>> Pkg1.calc.sum(1,2)
Traceback (most recent call last):
  File "<pyshell#42>", line 1, in <module>
    Pkg1.calc.sum(1,2)
AttributeError: 'module' object has no attribute 'sum'
>>> calc.add(1,2)
3
>>> 
